<?php
include('dbcon.php'); 
$RegNo=$_SESSION['uid'];
$query="Select* from login where RegNo=$RegNo";
$query_run=mysqli_query($conn,$query);
if(mysqli_num_rows($query_run)>0)
{
	$query1="SELECT * FROM `feestatus` WHERE RegNo ='$RegNo'";
	$query_run1=mysqli_query($conn,$query1);
	$row=mysqli_fetch_assoc($query_run1);
	$s1=$row['Status1'];
	$s2=$row['Status2'];
	$s3=$row['Status3'];
	$s4=$row['Status4'];
}
else
{
	echo '<script type="text/javascript">alert("Sorry you are not authorized person")</script>';
}
if(empty($_SESSION))
{
    header('Location: Adminlogin.php');
}
?>
	<html>
	<title>Login Page</title>

	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
		<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

		<style>
			.box {
				background-color: white;
				width: 100%;
				height: auto;
			}
			
			.img-responsive {
				border-style: solid;
				border-bottom: thick solid black;
			}
			
			.about {
				width: 100%;
				background-color: white;
				height: 70vh;
			}
			
			.mdl-mega-footer {
				background-color: black;
			}
			
			p1 {
				color: green;
			}
			
			p2 {
				color: red;
			}
		</style>
	</head>

	<body style="background-color:#E6E6FA">
		<!-- Always shows a header, even in smaller screens. -->
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<header class="mdl-layout__header" style="background-color:brown;">
				<div class="mdl-layout__header-row">
					<!-- Title -->
					<span class="mdl-layout-title"><img src="DPS-logo.jpg" style="width:40px; height:40px;"> ABC INTER COLLEGE</span>
					<!-- Add spacer, to align navigation to the right -->
					<div class="mdl-layout-spacer"></div>
					<!-- Navigation. We hide it in small screens. -->
					<nav class="mdl-navigation mdl-layout--large-screen-only">
						Welcome
						<?php echo $_SESSION['Name']?>
							<form action="attendance.php" method="post">
								<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout </button>
							</form>
					</nav>
				</div>
			</header>
			<div class="mdl-layout__drawer">
				<span class="mdl-layout-title"> ABC INTER COLLEGE</span>
				<nav class="mdl-navigation">
					<center>
						<?php echo $_SESSION['Name']?>
					</center>

					<form action="attendance.php" method="post">
						<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout </button>
					</form>
				</nav>
			</div>
			<main class="mdl-layout__content">
				<div class="page-content">

					<!-- Your content goes here -->

					<div class="mdl-grid mdl-grid--no-spacing">
						<div class="mdl-cell mdl-cell--10-col mdl-cell--1-offset-desktop mdl-cell--1-offset-tablet mdl-cell--6-col-tablet mdl-cell--4-col-phone">
							<div class="about">
								<ul class="nav nav-tabs">
									<li role="presentation"><a href="Std_home.php"> Student Details</a></li>
									<li role="presentation"><a href="results.php"> Results</a></li>
									<li role="presentation"><a href="attendance.php"> Attendance</a></li>
									<li role="presentation"><a href="polling.php"> Polling</a></li>
									<li role="presentation"><a href="change.php"> Change Password</a></li>
									<li role="presentation" class="active"><a href="fee.php"> Fee Status</a></li>
								</ul>
								<br>
								<fieldset>
									<legend>
										<center>
											<h3>Fee Status</h3>
									</legend>
								</fieldset>
								<form method="post" action="fee.php">

									<table class="table">
										<thead>
											<tr>
												<th>From</th>
												<th>To</th>
												<th>Status</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>January</td>
												<td>April</td>
												<td>
													<?php 
	                                               if($s1=='Paid')
                                                   {
	                                               ?>
														<p1>
															<?php echo $s1; ?>
														</p1>
														<?php	
                                                    }
	                                               else
												   {
		                                           ?>
															<p2>
																<?php echo $s1; ?>
															</p2>
															<?php }?>
												</td>

											</tr>
											<tr>
												<td>May</td>
												<td>August</td>
												<td>
													<?php 
	                                               if($s2=='Paid')
                                                   {
	                                               ?>
														<p1>
															<?php echo $s2; ?>
														</p1>
														<?php	
                                                    }
	                                               else
												   {
		                                           ?>
															<p2>
																<?php echo $s2; ?>
															</p2>
															<?php }?>
												</td>
											</tr>
											<tr>
												<td>September</td>
												<td>December</td>
												<td>
													<?php 
	                                               if($s3=='Paid')
                                                   {
	                                               ?>
														<p1>
															<?php echo $s3; ?>
														</p1>
														<?php	
                                                    }
	                                               else
												   {
		                                           ?>
															<p2>
																<?php echo $s3; ?>
															</p2>
															<?php }?>
												</td>
											</tr>
											<tr>
												<td colspan="2">Admission Fee</td>
												<td>
													<?php 
	                                               if($s4=='Paid')
                                                   {
	                                               ?>
														<p1>
															<?php echo $s4; ?>
														</p1>
														<?php	
                                                    }
	                                               else
												   {
		                                           ?>
															<p2>
																<?php echo $s4; ?>
															</p2>
															<?php }?>
												</td>
											</tr>
										</tbody>
									</table>
									<b>Note:</b>
									<p style="color:red;">It takes time to reflect on website the fee status of your account</p>
								</form>
							</div>
						</div>
					</div>










					<footer class="mdl-mega-footer">
						<div class="mdl-mega-footer__middle-section">

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Features</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">About</a></li>
									<li><a href="#">Terms</a></li>
									<li><a href="#">Partners</a></li>
									<li><a href="#">Updates</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Details</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Specs</a></li>
									<li><a href="#">Tools</a></li>
									<li><a href="#">Resources</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Technology</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">How it works</a></li>
									<li><a href="#">Patterns</a></li>
									<li><a href="#">Usage</a></li>
									<li><a href="#">Products</a></li>
									<li><a href="#">Contracts</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">FAQ</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Questions</a></li>
									<li><a href="#">Answers</a></li>
									<li><a href="#">Contact us</a></li>
								</ul>
							</div>

						</div>

						<div class="mdl-mega-footer__bottom-section">
							<div class="mdl-logo">Developer : Inamur Rahman</div>
							<ul class="mdl-mega-footer__link-list">
								<li><a href="#">Help</a></li>
								<li><a href="#">Privacy & Terms</a></li>
							</ul>
						</div>

					</footer>
				</div>
			</main>
		</div>

	</body>

	</html>
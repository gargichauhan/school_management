<?php
include('dbcon.php');
if(isset($_POST['logbtn']))
{
	$uid = $_POST['uid'];
	$pass = $_POST['password'];
	$query="select* from login where Password='$pass' AND RegNo='$uid'";
	$query1="select Name from std_details where RegNo='$uid'";
	$query2="select Percent from attendance where RegNo='$uid'";
	$query3="select Present from attendance where RegNo='$uid'";
	$query4="select Total from attendance where RegNo='$uid'";
	$query5="select* from std_details where RegNo='$uid'";
	$query_run = mysqli_query($conn,$query);
	$query_run1 = mysqli_query($conn,$query1);
	$query_run2 = mysqli_query($conn,$query2);
	$query_run3 = mysqli_query($conn,$query3);
	$query_run4 = mysqli_query($conn,$query4);
	$query_run5 = mysqli_query($conn,$query5);
	$row1 = mysqli_fetch_assoc($query_run1);
	$row2 = mysqli_fetch_assoc($query_run2);
	$row3 = mysqli_fetch_assoc($query_run3);
	$row4 = mysqli_fetch_assoc($query_run4);
	$row5 = mysqli_fetch_assoc($query_run5);
	if(mysqli_num_rows($query_run)>0)
	{
		$_SESSION['uid']=$uid;
		$_SESSION['Name']=($row1[Name]);
		$_SESSION['Percent']=($row2[Percent]);
		$_SESSION['Present']=($row3[Present]);
		$_SESSION['Total']=($row4[Total]);
		$_SESSION['Gender']=($row5[Gender]);
		$_SESSION['ClassName']=($row5[ClassName]);
		$_SESSION['Section']=($row5[Section]);
		$_SESSION['DoB']=($row5[DoB]);
		$_SESSION['FatherName']=($row5[FatherName]);
		$_SESSION['MotherName']=($row5[MotherName]);
		$_SESSION['ContNo']=($row5[ContNo]);
		$_SESSION['Address']=($row5[Address]);
		header('location:Std_home.php');
		
	}
	else
		echo '<script type="text/javascript">alert("You entered wrong Username or Password.")</script>';	
}

?>
	<html>
	<title>Login Page</title>

	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
		<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<script>
			$(document).ready(function () {

				loadProfile();
			});

			function getLocalProfile(callback) {
				var profileImgSrc = localStorage.getItem("PROFILE_IMG_SRC");
				var profileName = localStorage.getItem("PROFILE_NAME");
				var profileReAuthEmail = localStorage.getItem("PROFILE_REAUTH_EMAIL");

				if (profileName !== null && profileReAuthEmail !== null && profileImgSrc !== null) {
					callback(profileImgSrc, profileName, profileReAuthEmail);
				}
			}

			function loadProfile() {
				if (!supportsHTML5Storage()) {
					return false;
				}

				getLocalProfile(function (profileImgSrc, profileName, profileReAuthEmail) {
					//changes in the UI
					$("#profile-img").attr("src", profileImgSrc);
					$("#profile-name").html(profileName);
					$("#reauth-email").html(profileReAuthEmail);
					$("#inputEmail").hide();
					$("#remember").hide();
				});
			}


			function supportsHTML5Storage() {
				try {
					return 'localStorage' in window && window['localStorage'] !== null;
				} catch (e) {
					return false;
				}
			}


			function testLocalStorageData() {
				if (!supportsHTML5Storage()) {
					return false;
				}
		</script>
		<style>
			.box {
				background-color: white;
				width: 100%;
				height: auto;
			}
			
			.img-responsive {
				border-style: solid;
				border-bottom: thick solid black;
			}
			
			.about {
				width: 100%;
				background-color: dimgrey;
				height: 100vh;
			}
			
			.mdl-mega-footer {
				background-color: black;
			}
			
			.login {
				height: auto;
				margin-top: 25%;
				background-color: firebrick;
				box-shadow: 5px 5px 5px black;
			}
		</style>
	</head>

	<body style="background-color:#E6E6FA">
		<!-- Always shows a header, even in smaller screens. -->
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<header class="mdl-layout__header" style="background-color:brown;">
				<div class="mdl-layout__header-row">
					<!-- Title -->
					<span class="mdl-layout-title"><img src="DPS-logo.jpg" style="width:40px; height:40px;"> ABC INTER COLLEGE</span>
					<!-- Add spacer, to align navigation to the right -->
					<div class="mdl-layout-spacer"></div>
					<!-- Navigation. We hide it in small screens. -->
					<nav class="mdl-navigation mdl-layout--large-screen-only">
						<a class="mdl-navigation__link" href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
						<a class="mdl-navigation__link" href="admission.html"> <span class="glyphicon glyphicon-education" aria-hidden="true"></span> Admission</a>
						<a class="mdl-navigation__link" href="gallery.html"><span class="glyphicon glyphicon-picture" aria-hidden="true"></span> Gallery</a>
						<a class="mdl-navigation__link" href="contact.html"><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span> Contact</a>
						<a class="mdl-navigation__link" href="login.php"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Login</a>
					</nav>
				</div>
			</header>
			<div class="mdl-layout__drawer">
				<span class="mdl-layout-title"> ABC INTER COLLEGE</span>
				<nav class="mdl-navigation">
					<a class="mdl-navigation__link" href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
					<a class="mdl-navigation__link" href="admission.html"><span class="glyphicon glyphicon-education" aria-hidden="true"></span> Admission</a>
					<a class="mdl-navigation__link" href="gallery.html"><span class="glyphicon glyphicon-picture" aria-hidden="true"></span> Gallery</a>
					<a class="mdl-navigation__link" href="contact.html"><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span> Contact</a>
					<a class="mdl-navigation__link" href="login.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Login</a>
				</nav>
			</div>
			<main class="mdl-layout__content">
				<div class="page-content">

					<!-- Your content goes here -->

					<div class="mdl-grid mdl-grid--no-spacing">
						<div class="mdl-cell mdl-cell--12-col mdl-cell--8-col-tablet mdl-cell--4-col-phone">
							<div class="about">
								<div class="mdl-grid mdl-grid--no-spacing">
									<div class="mdl-cell mdl-cell--6-col-desktop mdl-cell--3-offset-desktop mdl-cell--6-col-tablet mdl-cell--1-offset-tablet mdl-cell--4-col-phone">


										<div class="card card-container">
											<center>
												<p style="font-size:22px;">Login to Account</p>
											</center>

											<img id="profile-img" class="profile-img-card" src="login.png" />
											<p id="profile-name" class="profile-name-card"></p>

											<form class="form-signin" action="login.php" method="post">
												<span id="reauth-email" class="reauth-email"></span>
												<select class="form-control" onchange="window.open(this.options[this.selectedIndex].value,'_top')">
													<option value="login.php">Student Login</option>
													<option value="Adminlogin.php">Admin Login</option>
												</select>
												<br>
												<input name="uid" type="text" id="inputEmail" class="form-control" placeholder="Unique ID" required autofocus pattern="[0-9]+">
												<input name="password" type="password" id="inputPassword" class="form-control" placeholder="Password" required>
												<div id="remember" class="checkbox">
													<label>
														<input type="checkbox" value="remember-me"> Remember me
													</label>
												</div>
												<button name="logbtn" class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Sign in</button>
											</form>
											<!-- /form -->
											<a href="Std_home.php" class="forgot-password">
                Forgot the password?
            </a>
										</div>
										<!-- /card-container -->




									</div>
								</div>
							</div>
						</div>
					</div>

					<footer class="mdl-mega-footer">
						<div class="mdl-mega-footer__middle-section">

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Features</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">About</a></li>
									<li><a href="#">Terms</a></li>
									<li><a href="#">Partners</a></li>
									<li><a href="#">Updates</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Details</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Specs</a></li>
									<li><a href="#">Tools</a></li>
									<li><a href="#">Resources</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Technology</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">How it works</a></li>
									<li><a href="#">Patterns</a></li>
									<li><a href="#">Usage</a></li>
									<li><a href="#">Products</a></li>
									<li><a href="#">Contracts</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">FAQ</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Questions</a></li>
									<li><a href="#">Answers</a></li>
									<li><a href="#">Contact us</a></li>
								</ul>
							</div>

						</div>

						<div class="mdl-mega-footer__bottom-section">
							<div class="mdl-logo">Developer : Inamur Rahman</div>
							<ul class="mdl-mega-footer__link-list">
								<li><a href="#">Help</a></li>
								<li><a href="#">Privacy & Terms</a></li>
							</ul>
						</div>

					</footer>
				</div>
			</main>
		</div>

	</body>

	</html>
<?php
include('dbcon.php');
    $RegNo =00000;
	$Name ='Unknown';
	$gender = 'Unknown';
	$classname ='Unknown';
	$Section ='Unknown';
	$DoB ='Unknown';
	$fname ='Unknown';
	$mname ='Unknown';
	$ContNo ='Unknown';
	$address ='Unknown';
if(empty($_SESSION))
{
    header('Location: Adminlogin.php');
}
if(isset($_POST['uid']))
{
	$uid=$_POST['uid'];
	$query="SELECT `RegNo`, `Name`, `Gender`, `ClassName`, `Section`, `DoB`, `FatherName`, `MotherName`, `ContNo`, `Address` FROM `std_details` WHERE RegNo='$uid'"; 
	$query_run=mysqli_query($conn,$query);
	if(mysqli_num_rows($query_run)>0)
	{
	$row=mysqli_fetch_assoc($query_run);
	$RegNo =$row['RegNo'];
	$Name =$row['Name'];
	$gender = $row['Gender'];
	$classname =$row['ClassName'];
	$Section =$row['Section'];
	$DoB =$row['DoB'];
	$fname =$row['FatherName'];
	$mname =$row['MotherName'];
	$ContNo =$row['ContNo'];
	$address =$row['Address'];
	}
	else
	{
		echo '<script type="text/javascript">alert("No students found please try again")</script>'; } } ?>
	<html>
	<title>Searching Page</title>

	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
		<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

		<style>
			.box {
				background-color: white;
				width: 100%;
				height: auto;
			}
			
			.img-responsive {
				border-style: solid;
				border-bottom: thick solid black;
			}
			
			.about {
				width: 100%;
				background-color: white;
				height: auto;
			}
			
			.mdl-mega-footer {
				background-color: black;
			}
			
			.about1 {
				width: 100%;
				background-color: white;
				height: auto;
			}
			
			body {
				background-color: #eee;
			}
			
			*[role="form"] {
				max-width: 530px;
				padding: 15px;
				margin: 0 auto;
				background-color: #fff;
				border-radius: 0.3em;
			}
			
			*[role="form"] h2 {
				margin-left: 5em;
				margin-bottom: 1em;
			}
		</style>
	</head>

	<body style="background-color:#E6E6FA">
		<!-- Always shows a header, even in smaller screens. -->
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<header class="mdl-layout__header" style="background-color:brown;">
				<div class="mdl-layout__header-row">
					<!-- Title -->
					<span class="mdl-layout-title"><img src="DPS-logo.jpg" style="width:40px; height:40px;"> ABC INTER COLLEGE</span>
					<!-- Add spacer, to align navigation to the right -->
					<div class="mdl-layout-spacer"></div>
					<!-- Navigation. We hide it in small screens. -->
					<nav class="mdl-navigation mdl-layout--large-screen-only">
						<a class="mdl-navigation__link" href="adminhome.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
						<a class="mdl-navigation__link" href="markattendance.php"> <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Attendance</a>
						<a class="mdl-navigation__link" href="viewthedresult.php"><span class="glyphicon glyphicon-signal" aria-hidden="true"></span></span>View Result</a>
						<a class="mdl-navigation__link" href="register.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Register</a>
						<a class="mdl-navigation__link" href="viewresult.php"><span class="glyphicon glyphicon-cloud-upload" aria-hidden="true">UploadResult</a>
						<form action="register.php" method="post">
							<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout <b><?php echo $_SESSION['uid']?></b> </button>
						</form>
					</nav>
				</div>
			</header>
			<div class="mdl-layout__drawer">
				<span class="mdl-layout-title"> ABC INTER COLLEGE</span>
				<nav class="mdl-navigation">
					<a class="mdl-navigation__link" href="adminhome.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
					<a class="mdl-navigation__link" href="markattendance.php"> <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Attendance</a>
					<a class="mdl-navigation__link" href="viewthedresult.php"><span class="glyphicon glyphicon-signal" aria-hidden="true"></span></span>View Result</a>
					<a class="mdl-navigation__link" href="register.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Register</a>
					<a class="mdl-navigation__link" href="viewresult.php"><span class="glyphicon glyphicon-cloud-upload" aria-hidden="true">UploadResult</a>
					<form action="register.php" method="post">
						<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout <b><?php echo $_SESSION['uid']?></b> </button>
					</form>
				</nav>
			</div>
			<main class="mdl-layout__content">
				<div class="page-content">

					<!-- Your content goes here -->

					<div class="mdl-grid mdl-grid--no-spacing">
						<div class="mdl-cell mdl-cell--10-col mdl-cell--1-offset-desktop mdl-cell--1-offset-tablet mdl-cell--6-col-tablet mdl-cell--4-col-phone">
							<div class="about">
								<br>
								<fieldset>
									<legend>
										<center>
											<h2>Search the Student.....</h2></center>
									</legend>
									<form class="form-horizontal" role="form" action="searchstd.php" method="post">
										<br>
										<br>
										<br>
										<br>
										<br>
										<div class="form-group">
											<div class="col-sm-12">
												<input type="number" class="form-control" rows="9" id="comment" placeholder="Enter Registration No........." name="uid">
												</textarea>
											</div>
										</div>
										<center>
											<button type="submit" class="btn btn-primary" name="submit">Search</button>
										</center>

									</form>
									<br>
									<center>
										<table class="mdl-data-table mdl-js-data-table">
											<tr>
												<td><b>Name</b></td>
												<td>
													<?php echo $Name ?>
												</td>
											</tr>
											<tr>
												<td><b>Registration No.</b></td>
												<td>
													<?php echo $RegNo ?>
												</td>
											</tr>
											<tr>
												<td><b>Father's Name</b></td>
												<td>
													<?php echo $fname ?>
												</td>
											</tr>
											<tr>
												<td><b>Mother's Name</b></td>
												<td>
													<?php echo $mname ?>
												</td>
											</tr>
											<tr>
												<td><b>Class</b></td>
												<td>
													<?php echo $classname."-".$Section ?>
												</td>
											</tr>
											<tr>
												<td><b>Gender</b></td>
												<td>
													<?php echo $gender ?>
												</td>
											</tr>
											<tr>
												<td><b>Date of Birth</b></td>
												<td>
													<?php echo $DoB ?>
												</td>
											</tr>
											<tr>
												<td><b>Contact No</b></td>
												<td>
													<?php echo $ContNo ?>
												</td>
											</tr>
											<tr>
												<td><b>Address: </b></td>
												<td>
													<?php echo $address ?>
												</td>
											</tr>
										</table>
									</center>
								</fieldset>
								<!-- /form -->
							</div>
							<!-- ./container -->

						</div>
					</div>

					<footer class="mdl-mega-footer">
						<div class="mdl-mega-footer__middle-section">

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Features</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">About</a></li>
									<li><a href="#">Terms</a></li>
									<li><a href="#">Partners</a></li>
									<li><a href="#">Updates</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Details</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Specs</a></li>
									<li><a href="#">Tools</a></li>
									<li><a href="#">Resources</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Technology</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">How it works</a></li>
									<li><a href="#">Patterns</a></li>
									<li><a href="#">Usage</a></li>
									<li><a href="#">Products</a></li>
									<li><a href="#">Contracts</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">FAQ</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Questions</a></li>
									<li><a href="#">Answers</a></li>
									<li><a href="#">Contact us</a></li>
								</ul>
							</div>

						</div>

						<div class="mdl-mega-footer__bottom-section">
							<div class="mdl-logo">Developer : Inamur Rahman</div>
							<ul class="mdl-mega-footer__link-list">
								<li><a href="#">Help</a></li>
								<li><a href="#">Privacy & Terms</a></li>
							</ul>
						</div>

					</footer>
				</div>
			</main>
		</div>

	</body>

	</html>
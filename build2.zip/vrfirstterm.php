<?php
include('dbcon.php');
if(empty($_SESSION))
{
    header('Location: Adminlogin.php');
}
	$RegNo1=$_SESSION['uid'];
    $query="SELECT * FROM admin WHERE RegNo='$RegNo1'";
	$query_run = mysqli_query($conn,$query);
	if(mysqli_num_rows($query_run)>0)
	{
		if(isset($_POST['submit']))
		{
			$class=$_POST['class'];
			$RegNo=$_POST['RegNo'];
			$_SESSION['class']=$class;
			$_SESSION['RegNo']=$RegNo;
			$table='r'.$class.'ft';
			$query3="select * from std_details where RegNo=$RegNo";
			$query1="select* from $table where RegNo=$RegNo";
			$query2="SHOW COLUMNS FROM $table";
			$_SESSION['query2']=$query2;
	        $query_run1=mysqli_query($conn,$query1);
	        $query_run2=mysqli_query($conn,$query2);
			$query_run3=mysqli_query($conn,$query3);
	        $row1=mysqli_fetch_assoc($query_run1);
	        $row2=mysqli_fetch_assoc($query_run2);
			$row3=mysqli_fetch_assoc($query_run3);
			$std_name=$row3['Name'];
			$_SESSION['Std_name']=$std_name;
	        $col=mysqli_num_fields($query_run);
		}
	}
	else
	{
		echo "<script type='text/javascript'>alert('You are not authorized person.')</script>";
    }
?>
	<html>
	<title>Login Page</title>

	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
		<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

		<style>
			.box {
				background-color: white;
				width: 100%;
				height: auto;
			}
			
			.img-responsive {
				border-style: solid;
				border-bottom: thick solid black;
			}
			
			.about {
				width: 100%;
				background-color: white;
				height: 200vh;
			}
			
			.mdl-mega-footer {
				background-color: black;
			}
			
			.about1 {
				width: 100%;
				background-color: white;
				height: auto;
			}
		</style>
	</head>

	<body style="background-color:#E6E6FA">
		<!-- Always shows a header, even in smaller screens. -->
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<header class="mdl-layout__header" style="background-color:brown;">
				<div class="mdl-layout__header-row">
					<!-- Title -->
					<span class="mdl-layout-title"><img src="DPS-logo.jpg" style="width:40px; height:40px;"> ABC INTER COLLEGE</span>
					<!-- Add spacer, to align navigation to the right -->
					<div class="mdl-layout-spacer"></div>
					<!-- Navigation. We hide it in small screens. -->
					<nav class="mdl-navigation mdl-layout--large-screen-only">
						<a class="mdl-navigation__link" href="adminhome.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
						<a class="mdl-navigation__link" href="markattendance.php"> <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Attendance</a>
						<a class="mdl-navigation__link" href="viewthedresult.php"><span class="glyphicon glyphicon-signal" aria-hidden="true"></span></span>View Result</a>
						<a class="mdl-navigation__link" href="register.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Register</a>
						<a class="mdl-navigation__link" href="viewresult.php"><span class="glyphicon glyphicon-cloud-upload" aria-hidden="true">UploadResult</a>
						<form action="register.php" method="post">
							<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout <b><?php echo $_SESSION['uid']?></b> </button>
						</form>
					</nav>
				</div>
			</header>
			<div class="mdl-layout__drawer">
				<span class="mdl-layout-title"> ABC INTER COLLEGE</span>
				<nav class="mdl-navigation">
					<a class="mdl-navigation__link" href="adminhome.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
					<a class="mdl-navigation__link" href="markattendance.php"> <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Attendance</a>
					<a class="mdl-navigation__link" href="viewthedresult.php"><span class="glyphicon glyphicon-signal" aria-hidden="true"></span></span>View Result</a>
					<a class="mdl-navigation__link" href="register.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Register</a>
					<a class="mdl-navigation__link" href="viewresult.php"><span class="glyphicon glyphicon-cloud-upload" aria-hidden="true">UploadResult</a>
					<form action="register.php" method="post">
						<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout <b><?php echo $_SESSION['uid']?></b> </button>
					</form>
				</nav>
			</div>
			<main class="mdl-layout__content">
				<div class="page-content">

					<!-- Your content goes here -->

					<div class="mdl-grid mdl-grid--no-spacing">
						<div class="mdl-cell mdl-cell--10-col mdl-cell--1-offset-desktop mdl-cell--1-offset-tablet mdl-cell--6-col-tablet mdl-cell--4-col-phone">
							<div class="about">

								<br>
								<form class="form-horizontal" method="post" action="vrfirstterm.php">
									<fieldset>
										<legend>
											<center>
												<h1>Result</h1></center>
										</legend>
										<div class="form-group">
											<div class="col-sm-5 col-sm-offset-4">
												<label class="control-label col-sm-8" for="email">Select Catagories</label>
												<select class="form-control" onchange="window.open(this.options[this.selectedIndex].value,'_top')">
													<option value="viewthedresult.php">Student Result</option>
													<option value="pollingresult.php">School Polling</option>
													<option value="std_attendance.php">View Attendance</option>
												</select>
											</div>
											<div class="col-sm-5 col-sm-offset-4">
												<label class="control-label col-sm-8" for="email">Select Exam Catagories</label>
												<select class="form-control" id="shel1" onchange="window.open(this.options[this.selectedIndex].value,'_top')">
													<option value="vrfirstterm.php">First Term</option>
													<option value="vrhalfyearly.php">Half Yearly</option>
													<option value="vrsecoundterm.php">Secound Term</option>
													<option value="vrfinalexam.php">Final Exam</option>

												</select>
											</div>
										</div>

										<div class="form-group">
											<div class="col-sm-offset-5 col-sm-3">
												<center>
													<label class="control-label">Class</label>
													<input type="number" name="class" placeholder="Enter the Class" class="form-control" autofocus required>
													<label class="control-label">Registration No. </label>
													<input type="number" name="RegNo" placeholder="Enter the Registration Number" class="form-control" autofocus required>
													<br>
													<button type="submit" name="submit" class="btn btn-success">Show</button>
												</center>
											</div>
										</div>
									</fieldset>

								</form>
								<?php
	if(isset($_POST['submit']))
{
								?>
									<center>
										<table class="class">
											<h5><b>Name : </b><?php echo $_SESSION['Std_name'] ?></h5>
											<?php
					                while($row2 = mysqli_fetch_array($query_run2)){
	?>
												<thead>
													<td>
														<?php echo $row2['Field']." ==> ".$row1[$row2['Field']]."/25"?>
															<br>
															<br>
													</td>
												</thead>
										</table>
										<?php }?>
									</center>
									<?php } ?>



							</div>
						</div>
					</div>

					<footer class="mdl-mega-footer">
						<div class="mdl-mega-footer__middle-section">

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Features</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">About</a></li>
									<li><a href="#">Terms</a></li>
									<li><a href="#">Partners</a></li>
									<li><a href="#">Updates</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Details</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Specs</a></li>
									<li><a href="#">Tools</a></li>
									<li><a href="#">Resources</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Technology</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">How it works</a></li>
									<li><a href="#">Patterns</a></li>
									<li><a href="#">Usage</a></li>
									<li><a href="#">Products</a></li>
									<li><a href="#">Contracts</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">FAQ</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Questions</a></li>
									<li><a href="#">Answers</a></li>
									<li><a href="#">Contact us</a></li>
								</ul>
							</div>

						</div>

						<div class="mdl-mega-footer__bottom-section">
							<div class="mdl-logo">Developer : Inamur Rahman</div>
							<ul class="mdl-mega-footer__link-list">
								<li><a href="#">Help</a></li>
								<li><a href="#">Privacy & Terms</a></li>
							</ul>
						</div>

					</footer>
				</div>
			</main>
		</div>

	</body>

	</html>
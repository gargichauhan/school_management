<?php
include('dbcon.php');
	$table='r'.$_SESSION['ClassName'].'hy';
	$uid=$_SESSION['uid'];
	$query="SELECT* FROM $table where RegNo =$uid";
	$query1="SHOW COLUMNS FROM $table";
	$query_run=mysqli_query($conn,$query);
	$query_run1=mysqli_query($conn,$query1);
	$row=mysqli_fetch_assoc($query_run);
	$row1=mysqli_fetch_assoc($query_run1);
	$col=mysqli_num_fields($query_run);
if(empty($_SESSION))
{
    header('Location: Adminlogin.php');
}
?>
	<html>
	<title>Login Page</title>

	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
		<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

		<style>
			.box {
				background-color: white;
				width: 100%;
				height: auto;
			}
			
			.img-responsive {
				border-style: solid;
				border-bottom: thick solid black;
			}
			
			.about {
				width: 100%;
				background-color: white;
				height: 100vh;
			}
			
			.mdl-mega-footer {
				background-color: black;
			}
			
			.about1 {
				width: 100%;
				background-color: white;
				height: auto;
			}
		</style>
	</head>

	<body style="background-color:#E6E6FA">
		<!-- Always shows a header, even in smaller screens. -->
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<header class="mdl-layout__header" style="background-color:brown;">
				<div class="mdl-layout__header-row">
					<!-- Title -->
					<span class="mdl-layout-title"><img src="DPS-logo.jpg" style="width:40px; height:40px;"> ABC INTER COLLEGE</span>
					<!-- Add spacer, to align navigation to the right -->
					<div class="mdl-layout-spacer"></div>
					<!-- Navigation. We hide it in small screens. -->
					<nav class="mdl-navigation mdl-layout--large-screen-only">
						Welcome
						<?php echo $_SESSION['Name']?>
							<form action="results.php" method="post">
								<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout </button>
							</form>
					</nav>
				</div>
			</header>
			<div class="mdl-layout__drawer">
				<span class="mdl-layout-title"> ABC INTER COLLEGE</span>
				<nav class="mdl-navigation">
					<center>
						<?php echo $_SESSION['Name']?>
					</center>

					<form action="results.php" method="post">
						<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout </button>
					</form>
				</nav>
			</div>
			<main class="mdl-layout__content">
				<div class="page-content">

					<!-- Your content goes here -->

					<div class="mdl-grid mdl-grid--no-spacing">
						<div class="mdl-cell mdl-cell--10-col mdl-cell--1-offset-desktop mdl-cell--1-offset-tablet mdl-cell--6-col-tablet mdl-cell--4-col-phone">
							<div class="about">
								<ul class="nav nav-tabs">
									<li role="presentation"><a href="Std_home.php"> Student Details</a></li>
									<li role="presentation" class="active"><a href="results.php"> Results</a></li>
									<li role="presentation"><a href="attendance.php"> Attendance</a></li>
									<li role="presentation"><a href="polling.php"> Polling</a></li>
									<li role="presentation"><a href="change.php"> Change Password</a></li>
									<li role="presentation"><a href="fee.php"> Fee Status</a></li>
								</ul>
								<br>
								<form class="form-horizontal">
									<fieldset>
										<legend>
											<center>
												<h1>Result</h1></center>
										</legend>
										<div class="form-group">
											<label class="control-label col-sm-4" for="email">Select Exam Catagories</label>
											<div class="col-sm-5">
												<select class="form-control" id="shel1" onchange="window.open(this.options[this.selectedIndex].value,'_top')">
													<option value="halfyearly.php">Half Yearly</option>
													<option value="firstterm.php">First Term</option>
													<option value="secoundterm.php">Secound Term</option>
													<option value="finalexam.php">Final Exam</option>

												</select>
											</div>
										</div>


									</fieldset>
								</form>
								<table class="table">

									<tr>
										<?php
					while($row1 = mysqli_fetch_array($query_run1)){
	?>
											<thead>
												<td>
													<?php echo $row1['Field']."--->".$row[$row1['Field']]."/50"?>
												</td>
											</thead>
											<?php } ?>
									</tr>

								</table>

							</div>
						</div>
					</div>

					<footer class=" mdl-mega-footer ">
						<div class="mdl-mega-footer__middle-section ">

							<div class="mdl-mega-footer__drop-down-section ">
								<input class="mdl-mega-footer__heading-checkbox " type="checkbox " checked>
								<h1 class="mdl-mega-footer__heading ">Features</h1>
								<ul class="mdl-mega-footer__link-list ">
									<li><a href="# ">About</a></li>
									<li><a href="# ">Terms</a></li>
									<li><a href="# ">Partners</a></li>
									<li><a href="# ">Updates</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section ">
								<input class="mdl-mega-footer__heading-checkbox " type="checkbox " checked>
								<h1 class="mdl-mega-footer__heading ">Details</h1>
								<ul class="mdl-mega-footer__link-list ">
									<li><a href="# ">Specs</a></li>
									<li><a href="# ">Tools</a></li>
									<li><a href="# ">Resources</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section ">
								<input class="mdl-mega-footer__heading-checkbox " type="checkbox " checked>
								<h1 class="mdl-mega-footer__heading ">Technology</h1>
								<ul class="mdl-mega-footer__link-list ">
									<li><a href="# ">How it works</a></li>
									<li><a href="# ">Patterns</a></li>
									<li><a href="# ">Usage</a></li>
									<li><a href="# ">Products</a></li>
									<li><a href="# ">Contracts</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section ">
								<input class="mdl-mega-footer__heading-checkbox " type="checkbox " checked>
								<h1 class="mdl-mega-footer__heading ">FAQ</h1>
								<ul class="mdl-mega-footer__link-list ">
									<li><a href="# ">Questions</a></li>
									<li><a href="# ">Answers</a></li>
									<li><a href="# ">Contact us</a></li>
								</ul>
							</div>

						</div>

						<div class="mdl-mega-footer__bottom-section ">
							<div class="mdl-logo ">Developer : Inamur Rahman</div>
							<ul class="mdl-mega-footer__link-list ">
								<li><a href="# ">Help</a></li>
								<li><a href="# ">Privacy & Terms</a></li>
							</ul>
						</div>

					</footer>
				</div>
			</main>
		</div>

	</body>

	</html>
<?php
include('dbcon.php');

if(isset($_POST['regbtn']))
{
	//echo '<script type="text/javascript">alert("Clicked")</script>';
	$fullname = $_POST['fullname'];
	$fname = $_POST['fname'];
	$mname = $_POST['mname'];
	$class = $_POST['class'];
	$address = $_POST['address'];
	$uid = $_POST['uid'];
	$gender = $_POST['gender'];
	$DoB = $_POST['DoB'];
	$contno = $_POST['contno'];
	$section = $_POST['section'];
	$image = $_FILES['simg']['name'];
	$tempimage = $_FILES['simg']['tmp_name'];
	move_uploaded_file($tempimage,"uploads/$image");
	$query="SELECT * FROM `std_details` WHERE RegNo='$uid'";
	$query1="INSERT INTO `std_details`(`RegNo`, `Name`, `Gender`, `ClassName`, `Section`, `DoB`, `FatherName`, `MotherName`, `ContNo`, `Address`, `image`) VALUES ('$uid','$fullname','$gender','$class','$section','$DoB','$fname','$mname','$contno','$address','$image')";
	$query_run = mysqli_query($conn,$query);
	if(mysqli_num_rows($query_run)>0)
	{
		echo '<script type="text/javascript">alert("User Already Exist")</script>';
	}
	else
	{
		$query_run1 = mysqli_query($conn,$query1);
	    if($query_run1)
			{
			echo '<script type="text/javascript">alert("Data entered successfully")</script>';
		    }
	}
}
if(empty($_SESSION))
{
    header('Location: Adminlogin.php');
}
?>
	<html>
	<title>Registration</title>

	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
		<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

		<style>
			.box {
				background-color: white;
				width: 100%;
				height: auto;
			}
			
			.img-responsive {
				border-style: solid;
				border-bottom: thick solid black;
			}
			
			.about {
				width: 100%;
				background-color: white;
				height: auto;
			}
			
			.mdl-mega-footer {
				background-color: black;
			}
			
			.about1 {
				width: 100%;
				background-color: white;
				height: auto;
			}
			
			body {
				background-color: #eee;
			}
			
			*[role="form"] {
				max-width: 530px;
				padding: 15px;
				margin: 0 auto;
				background-color: #fff;
				border-radius: 0.3em;
			}
			
			*[role="form"] h2 {
				margin-left: 5em;
				margin-bottom: 1em;
			}
		</style>
	</head>

	<body style="background-color:#E6E6FA">
		<!-- Always shows a header, even in smaller screens. -->
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<header class="mdl-layout__header" style="background-color:brown;">
				<div class="mdl-layout__header-row">
					<!-- Title -->
					<span class="mdl-layout-title"><img src="DPS-logo.jpg" style="width:40px; height:40px;"> ABC INTER COLLEGE</span>
					<!-- Add spacer, to align navigation to the right -->
					<div class="mdl-layout-spacer"></div>
					<!-- Navigation. We hide it in small screens. -->
					<nav class="mdl-navigation mdl-layout--large-screen-only">
						<a class="mdl-navigation__link" href="adminhome.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
						<a class="mdl-navigation__link" href="markattendance.php"> <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Attendance</a>
						<a class="mdl-navigation__link" href="viewthedresult.php"><span class="glyphicon glyphicon-signal" aria-hidden="true"></span></span>View Result</a>
						<a class="mdl-navigation__link" href="register.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Register</a>
						<a class="mdl-navigation__link" href="viewresult.php"><span class="glyphicon glyphicon-cloud-upload" aria-hidden="true">UploadResult</a>
						<form action="register.php" method="post">
							<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout <b><?php echo $_SESSION['uid']?></b> </button>
						</form>
					</nav>
				</div>
			</header>
			<div class="mdl-layout__drawer">
				<span class="mdl-layout-title"> ABC INTER COLLEGE</span>
				<nav class="mdl-navigation">
					<a class="mdl-navigation__link" href="adminhome.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
					<a class="mdl-navigation__link" href="markattendance.php"> <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Attendance</a>
					<a class="mdl-navigation__link" href="viewthedresult.php"><span class="glyphicon glyphicon-signal" aria-hidden="true"></span></span>View Result</a>
					<a class="mdl-navigation__link" href="register.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Register</a>
					<a class="mdl-navigation__link" href="viewresult.php"><span class="glyphicon glyphicon-cloud-upload" aria-hidden="true">UploadResult</a>
					<form action="register.php" method="post">
						<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout <b><?php echo $_SESSION['uid']?></b> </button>
					</form>
				</nav>
			</div>
			<main class="mdl-layout__content">
				<div class="page-content">

					<!-- Your content goes here -->

					<div class="mdl-grid mdl-grid--no-spacing">
						<div class="mdl-cell mdl-cell--10-col mdl-cell--1-offset-desktop mdl-cell--1-offset-tablet mdl-cell--6-col-tablet mdl-cell--4-col-phone">
							<div class="about">
								<br>
								<fieldset>
									<legend>
										<center>
											<h2>Registration Form</h2></center>
									</legend>
									<form class="form-horizontal" role="form" action="register.php" method="post" enctype="multipart/form-data">

										<div class="form-group">
											<label for="firstName" class="col-sm-3 control-label">Full Name</label>
											<div class="col-sm-9">
												<input type="text" name="fullname" id="firstName" placeholder="Full Name" class="form-control" autofocus required>
												<span class="help-block">Last Name, First Name, eg.: Smith, Harry</span>
											</div>
										</div>
										<div class="form-group">
											<label for="firstName" class="col-sm-3 control-label">Registration No.</label>
											<div class="col-sm-9">
												<input name="uid" type="number" id="firstName" placeholder="Enter Registration No." class="form-control" autofocus required>

											</div>
										</div>
										<div class="form-group">
											<label for="email" class="col-sm-3 control-label">Father's Name</label>
											<div class="col-sm-9">
												<input name="fname" type="text" id="email" placeholder="Enter Father's Name" class="form-control" required>
											</div>
										</div>
										<div class="form-group">
											<label for="password" class="col-sm-3 control-label">Mother's Name</label>
											<div class="col-sm-9">
												<input name="mname" type="text" id="password" placeholder="Enter Mother's Name" class="form-control" required>
											</div>
										</div>
										<div class="form-group">
											<label for="password" class="col-sm-3 control-label">Class</label>
											<div class="col-sm-4">
												<input name="class" type="number" id="password" placeholder="Enter class" class="form-control" required>
											</div>
											<div class="col-sm-4">
												<input name="section" type="text" id="password" placeholder="Section" class="form-control" required>
											</div>
										</div>
										<div class="form-group">
											<label for="birthDate" class="col-sm-3 control-label">Date of Birth</label>
											<div class="col-sm-9">
												<input name="DoB" type="date" id="birthDate" class="form-control" required>
											</div>
										</div>
										<!-- /.form-group -->
										<div class="form-group">
											<label class="control-label col-sm-3">Gender</label>
											<div class="col-sm-6">
												<div class="row">
													<div class="col-sm-4">
														<label class="radio-inline">
															<input type="radio" name="gender" id="femaleRadio" value="Female" required>Female
														</label>
													</div>
													<div class="col-sm-4">
														<label class="radio-inline">
															<input type="radio" name="gender" id="maleRadio" value="Male" required>Male
														</label>
													</div>

												</div>
											</div>
										</div>
										<div class="form-group">
											<label for="password" class="col-sm-3 control-label">Enter Address</label>
											<div class="col-sm-9">
												<input name="address" type="text" id="password" placeholder="Enter Address" class="form-control" required>
											</div>
										</div>
										<!-- /.form-group -->
										<label for="password" class="col-sm-3 control-label">Contact Number</label>
										<div class="col-sm-9">
											<input name="contno" type="number" id="password" placeholder="9000000000" class="form-control" required>
										</div>
										<!-- /.form-group -->
										<div class="form-group">
											<div class="col-sm-9 col-sm-offset-3">
												<div>
													<label>
														<b>Upload Image</b>
														<input type="file" name="simg" required>
													</label>
												</div>
											</div>
										</div>
										<div class="form-group">
											<div class="col-sm-9 col-sm-offset-3">
												<div class="checkbox">
													<label>
														<input type="checkbox" required>I have checked all the data is written correctly.
													</label>
												</div>
											</div>
										</div>
										<!-- /.form-group -->
										<div class="form-group">
											<div class="col-sm-9 col-sm-offset-3">
												<button name="regbtn" type="submit" class="btn btn-primary btn-block">Register</button>
											</div>
										</div>
									</form>
								</fieldset>
								<!-- /form -->
							</div>
							<!-- ./container -->

						</div>
					</div>

					<footer class="mdl-mega-footer">
						<div class="mdl-mega-footer__middle-section">

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Features</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">About</a></li>
									<li><a href="#">Terms</a></li>
									<li><a href="#">Partners</a></li>
									<li><a href="#">Updates</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Details</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Specs</a></li>
									<li><a href="#">Tools</a></li>
									<li><a href="#">Resources</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">Technology</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">How it works</a></li>
									<li><a href="#">Patterns</a></li>
									<li><a href="#">Usage</a></li>
									<li><a href="#">Products</a></li>
									<li><a href="#">Contracts</a></li>
								</ul>
							</div>

							<div class="mdl-mega-footer__drop-down-section">
								<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
								<h1 class="mdl-mega-footer__heading">FAQ</h1>
								<ul class="mdl-mega-footer__link-list">
									<li><a href="#">Questions</a></li>
									<li><a href="#">Answers</a></li>
									<li><a href="#">Contact us</a></li>
								</ul>
							</div>

						</div>

						<div class="mdl-mega-footer__bottom-section">
							<div class="mdl-logo">Developer : Inamur Rahman</div>
							<ul class="mdl-mega-footer__link-list">
								<li><a href="#">Help</a></li>
								<li><a href="#">Privacy & Terms</a></li>
							</ul>
						</div>

					</footer>
				</div>
			</main>
		</div>

	</body>

	</html>
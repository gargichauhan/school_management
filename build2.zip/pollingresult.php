<?php
include('dbcon.php');
if(empty($_SESSION))
{
    header('Location: Adminlogin.php');
}
$query1="SELECT * FROM schoolcaptain WHERE CanditateName='Aman Kumar'";
$query2="SELECT * FROM schoolcaptain WHERE CanditateName='Rehan Khan'";
$query3="SELECT * FROM schoolcaptain WHERE CanditateName='Amit Singh'";
$query4="SELECT * FROM schoolcaptain WHERE CanditateName='Kunal Pandey'";
$query5="SELECT * FROM `schoolvicecaptain` WHERE CandidateName = 'Zaheer Khan'";
$query6="SELECT * FROM `schoolvicecaptain` WHERE CandidateName = 'Virat Kohli'";
$query7="SELECT * FROM `schoolvicecaptain` WHERE CandidateName = 'Sachin'";
$query8="SELECT * FROM `schoolvicecaptain` WHERE CandidateName = 'Youraj'";
$query_run1 = mysqli_query($conn,$query1);
$query_run2 = mysqli_query($conn,$query2);
$query_run3 = mysqli_query($conn,$query3);
$query_run4 = mysqli_query($conn,$query4);
$query_run5 = mysqli_query($conn,$query5);
$query_run6 = mysqli_query($conn,$query6);
$query_run7 = mysqli_query($conn,$query7);
$query_run8 = mysqli_query($conn,$query8);
$count1=mysqli_num_rows($query_run1);
$count2=mysqli_num_rows($query_run2);
$count3=mysqli_num_rows($query_run3);
$count4=mysqli_num_rows($query_run4);
$count5=mysqli_num_rows($query_run5);
$count6=mysqli_num_rows($query_run6);
$count7=mysqli_num_rows($query_run7);
$count8=mysqli_num_rows($query_run8);
$total_vote=$count1+$count2+$count3+$count4;
$per1=($count1/$total_vote)*100;
$per2=($count2/$total_vote)*100;
$per3=($count3/$total_vote)*100;
$per4=($count4/$total_vote)*100;
$total_vote1=$count5+$count6+$count7+$count8;
$per5=($count5/$total_vote1)*100;
$per6=($count6/$total_vote1)*100;
$per7=($count7/$total_vote1)*100;
$per8=($count8/$total_vote1)*100;
?>
	<html>
	<title>Result</title>

	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
		<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

		<style>
			.box {
				background-color: white;
				width: 100%;
				height: auto;
			}
			
			.img-responsive {
				border-style: solid;
				border-bottom: thick solid black;
			}
			
			.about {
				width: 100%;
				background-color: white;
				height: auto;
			}
			
			.mdl-mega-footer {
				background-color: black;
			}
			
			.about1 {
				width: 100%;
				background-color: white;
				height: auto;
			}
			
			body {
				background-color: #eee;
			}
			
			*[role="form"] {
				max-width: 530px;
				padding: 15px;
				margin: 0 auto;
				background-color: #fff;
				border-radius: 0.3em;
			}
			
			*[role="form"] h2 {
				margin-left: 5em;
				margin-bottom: 1em;
			}
		</style>
	</head>

	<body style="background-color:#E6E6FA">
		<!-- Always shows a header, even in smaller screens. -->
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<header class="mdl-layout__header" style="background-color:brown;">
				<div class="mdl-layout__header-row">
					<!-- Title -->
					<span class="mdl-layout-title"><img src="DPS-logo.jpg" style="width:40px; height:40px;"> ABC INTER COLLEGE</span>
					<!-- Add spacer, to align navigation to the right -->
					<div class="mdl-layout-spacer"></div>
					<!-- Navigation. We hide it in small screens. -->
					<nav class="mdl-navigation mdl-layout--large-screen-only">
						<a class="mdl-navigation__link" href="adminhome.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
						<a class="mdl-navigation__link" href="markattendance.php"> <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Attendance</a>
						<a class="mdl-navigation__link" href="uploadresult.php"><span class="glyphicon glyphicon-cloud-upload" aria-hidden="true"></span> Upload Result</a>
						<a class="mdl-navigation__link" href="register.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Register</a>
						<a class="mdl-navigation__link" href="viewresult.php"><span class="glyphicon glyphicon-signal" aria-hidden="true"></span> View Result</a>
						<form action="register.php" method="post">
							<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout <b><?php echo $_SESSION['uid']?></b> </button>
						</form>
					</nav>
				</div>
			</header>
			<div class="mdl-layout__drawer">
				<span class="mdl-layout-title">ABC INTER COLLEGE</span>
				<nav class="mdl-navigation">
					<a class="mdl-navigation__link" href="adminhome.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
					<a class="mdl-navigation__link" href="markattendance.php"> <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Attendance</a>
					<a class="mdl-navigation__link" href="uploadresult.php"><span class="glyphicon glyphicon-cloud-upload" aria-hidden="true"></span> Upload Result</a>
					<a class="mdl-navigation__link" href="register.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Register</a>
					<a class="mdl-navigation__link" href="viewresult.php"><span class="glyphicon glyphicon-signal" aria-hidden="true"></span> View Result</a>
					<form action="register.php" method="post">
						<button class="btn-success" name="Logout"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Logout <b><?php echo $_SESSION['uid']?></b> </button>
					</form>
				</nav>
			</div>
			<main class="mdl-layout__content">
				<div class="page-content">

					<!-- Your content goes here -->

					<div class="mdl-grid mdl-grid--no-spacing">
						<div class="mdl-cell mdl-cell--10-col mdl-cell--1-offset-desktop mdl-cell--1-offset-tablet mdl-cell--6-col-tablet mdl-cell--4-col-phone">
							<div class="about">
								<br>
								<fieldset>
									<legend>
										<center>
											<h2>Results</h2></center>
									</legend>
									<form class="form-horizontal" role="form" action="markattendance.php" method="post">
										<label class="col-sm-7 control-label">Select Catagories</label>
										<select class="form-control" onchange="window.open(this.options[this.selectedIndex].value,'_top')">
											<option value="pollingresult.php">School Polling</option>
											<option value="std_result.php">Student Result</option>
											<option value="std_attendance.php">View Attendance</option>
										</select>
									</form>
									<center>

										<h3>School Captain</h3>
										<h5>Aman Kumar</h5>
										<div class="progress" style="width:70%;">
											<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per1 ?>%">
												<?php echo $per1 ?>% (
													<?php echo $count1 ?>)
											</div>
										</div>
										<h5>Rehan Khan</h5>
										<div class="progress" style="width:70%;">
											<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per2 ?>%">
												<?php echo $per2 ?>% (
													<?php echo $count2 ?>)
											</div>
										</div>
										<h5>Amit Singh</h5>
										<div class="progress" style="width:70%;">
											<div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per3 ?>%">
												<?php echo $per3 ?>% (
													<?php echo $count3 ?>)
											</div>
										</div>
										<h5>Kunal Pandey</h5>
										<div class="progress" style="width:70%;">
											<div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per4 ?>%">
												<?php echo $per4 ?>% (
													<?php echo $count4 ?>)
											</div>
										</div>
										<br>
										<hr>
										<h3>School Vice-Captain</h3>
										<h5>Candidate_1</h5>
										<div class="progress" style="width:70%;">
											<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per5 ?>%">
												<?php echo $per5 ?>% (
													<?php echo $count5 ?>)
											</div>
										</div>
										<h5>Candidate_1</h5>
										<div class="progress" style="width:70%;">
											<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per6 ?>%">
												<?php echo $per6 ?>% (
													<?php echo $count6 ?>)
											</div>
										</div>
										<h5>Candidate_1</h5>
										<div class="progress" style="width:70%;">
											<div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per7 ?>%">
												<?php echo $per7 ?>% (
													<?php echo $count7 ?>)
											</div>
										</div>
										<h5>Candidate_1</h5>
										<div class="progress" style="width:70%;">
											<div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $per8 ?>%">
												<?php echo $per8 ?>% (
													<?php echo $count8 ?>)
											</div>
										</div>
										<br>

									</center>
							</div>



							</fieldset>

							<!-- /form -->
						</div>
						<!-- ./container -->

					</div>
				</div>

				<footer class="mdl-mega-footer">
					<div class="mdl-mega-footer__middle-section">

						<div class="mdl-mega-footer__drop-down-section">
							<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
							<h1 class="mdl-mega-footer__heading">Features</h1>
							<ul class="mdl-mega-footer__link-list">
								<li><a href="#">About</a></li>
								<li><a href="#">Terms</a></li>
								<li><a href="#">Partners</a></li>
								<li><a href="#">Updates</a></li>
							</ul>
						</div>

						<div class="mdl-mega-footer__drop-down-section">
							<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
							<h1 class="mdl-mega-footer__heading">Details</h1>
							<ul class="mdl-mega-footer__link-list">
								<li><a href="#">Specs</a></li>
								<li><a href="#">Tools</a></li>
								<li><a href="#">Resources</a></li>
							</ul>
						</div>

						<div class="mdl-mega-footer__drop-down-section">
							<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
							<h1 class="mdl-mega-footer__heading">Technology</h1>
							<ul class="mdl-mega-footer__link-list">
								<li><a href="#">How it works</a></li>
								<li><a href="#">Patterns</a></li>
								<li><a href="#">Usage</a></li>
								<li><a href="#">Products</a></li>
								<li><a href="#">Contracts</a></li>
							</ul>
						</div>

						<div class="mdl-mega-footer__drop-down-section">
							<input class="mdl-mega-footer__heading-checkbox" type="checkbox" checked>
							<h1 class="mdl-mega-footer__heading">FAQ</h1>
							<ul class="mdl-mega-footer__link-list">
								<li><a href="#">Questions</a></li>
								<li><a href="#">Answers</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>

					</div>

					<div class="mdl-mega-footer__bottom-section">
						<div class="mdl-logo">Developer : Inamur Rahman</div>
						<ul class="mdl-mega-footer__link-list">
							<li><a href="#">Help</a></li>
							<li><a href="#">Privacy & Terms</a></li>
						</ul>
					</div>

				</footer>
		</div>
		</main>
		</div>

	</body>

	</html>
<?php
include('dbcon.php');
$query1="SELECT * FROM `notice`";
$query_run1=mysqli_query($conn,$query1);
$row=mysqli_fetch_assoc($query_run1);
?>
	<html>
	<title>Result</title>

	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
		<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

		<style>
			.img-responsive {
				border-style: solid;
				border-bottom: thick solid black;
			}
			
			.about {
				width: 100%;
				background-color: #d6d6c2;
				height: 100vh;
			}
			
			body {
				background-color: #d6d6c2;
			}
		</style>
	</head>

	<body>
		<!-- Your content goes here -->
		<div class="mdl-grid mdl-grid--no-spacing">
			<div class="mdl-cell mdl-cell--12-col mdl-cell--0-offset-desktop mdl-cell--0-offset-tablet mdl-cell--8-col-tablet mdl-cell--4-col-phone">
				<div class="about">
					<?php while($row = mysqli_fetch_array($query_run1))
{ ?>
						<b><h3><?php echo "#".$row['Id']." ".$row['Heading'] ?></h3></b>
						<h5><?php echo $row['Body'] ?></h5>
						<?php 
} ?>
				</div>
			</div>
		</div>
	</body>

	</html>